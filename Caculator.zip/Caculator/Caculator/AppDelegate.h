//
//  AppDelegate.h
//  Caculater
//
//  Created by Yatish on 01/07/16.
//  Copyright © 2016 Yatish. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

